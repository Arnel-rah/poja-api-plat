package com.example.demo;

import static java.nio.file.Files.readString;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.nio.file.Files;

import static java.nio.file.Files.readString;
@SpringBootApplication
public class DemoApplication {
	public
		static void
			main(String[] args)
	{
		SpringApplication.run(DemoApplication.class, args);
	}
}
