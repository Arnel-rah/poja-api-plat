package com.hei.poja_maven_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PojaMavenProjectApplication {

  public static void main(String[] args) {
    SpringApplication.run(PojaMavenProjectApplication.class, args);
  }
}
