package com.hei.poja_maven_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PojaMavenProjectApplicationTests {

  @Test
  void contextLoads() {}
}
